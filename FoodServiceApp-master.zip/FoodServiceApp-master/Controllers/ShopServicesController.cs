﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Controllers
{
    public class ShopServicesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public ShopServicesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Create()
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            ViewData["shopId"] = shopId;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,ShopId,IsActive,ServesVegan,ServesNonVeg,ServesAlcohol,DeliversAlcohol")] ShopServices shopServices)
        {
            if (ModelState.IsValid)
            {
                _unitOfWork.ShopServicesRepository.Add(shopServices);
                _unitOfWork.ShopServicesRepository.Save();
                return RedirectToAction("Index", "Dashboard");
            }
            return View(shopServices);
        }

        public IActionResult Edit()
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            var shopServices = _unitOfWork.ShopServicesRepository.GetShopServicesByShopId(shopId);
            if (shopServices == null)
            {
                return NotFound();
            }
            return View(shopServices);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit([Bind("Id,ShopId,IsActive,ServesVegan,ServesNonVeg,ServesAlcohol,DeliversAlcohol")] ShopServices shopServices)
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            if (ModelState.IsValid)
            {
                try
                {
                    _unitOfWork.ShopServicesRepository.Update(shopServices);
                    _unitOfWork.ShopServicesRepository.Save();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ShopServicesExists(shopServices.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index", "Dashboard");
            }
            return View(shopServices);
        }
        private bool ShopServicesExists(int id)
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            return _unitOfWork.ShopServicesRepository.Any(s => s.ShopId == id);
        }
    }
}

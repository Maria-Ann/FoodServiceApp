﻿using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Controllers
{
    public class OrdersController : Controller
    {
        public readonly IUnitOfWork _unitOfWork;
        public OrdersController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            //Initialize and load values to DTO
            var ShopId = HttpContext.Session.GetInt32("shopId");
            if (ShopId == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                OrdersDTO ordersList = new()
                {
                    OrdersList = _unitOfWork.CartRepository.GetShopOrders((int)ShopId),
                    ConfirmedList = _unitOfWork.CartRepository.GetShopConfirmedOrders((int)ShopId),
                    ShippedList = _unitOfWork.CartRepository.GetShopShippedOrders((int)ShopId),
                    DeliveredList = _unitOfWork.CartRepository.GetShopDeliveredOrders((int)ShopId),
                };
                return View(ordersList);
            }
        }
        public IActionResult ConfirmOrder(int CartItemId) {
            //Change order status to Confirmed
            var cartItem = _unitOfWork.CartRepository.GetById(CartItemId);
            _unitOfWork.CartRepository.SetConfirmed(cartItem);
            return RedirectToAction("Index");
        }
        public IActionResult ShipOrder(int CartItemId) {
            //Change order status to Shipped
            var cartItem = _unitOfWork.CartRepository.GetById(CartItemId);
            _unitOfWork.CartRepository.SetShipped(cartItem);
            return RedirectToAction("Index");
        }
        public IActionResult DeliverOrder(int CartItemId) {
            //Change order status to Delivered
            var cartItem = _unitOfWork.CartRepository.GetById(CartItemId);
            _unitOfWork.CartRepository.SetDelivered(cartItem);
            return RedirectToAction("Index");
        }
        
    }
}

﻿using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public HomeController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index()
        {
            //Initialize and load values to DTO
            var userId = HttpContext.Session.GetInt32("userId");
            var shopId = HttpContext.Session.GetInt32("shopId");
            if(userId != null && userId > 0) {
                return RedirectToAction("Index","Listing");
            }else if(shopId != null && shopId > 0) {
                return RedirectToAction("Index", "Dashboard");
            }
            return View();
        }
        public IActionResult Logout()
        {
            //Executed when Logout is Clicked
            HttpContext.Session.Remove("userId");
            HttpContext.Session.Remove("shopId");
            return RedirectToAction("Index");
        }
        public IActionResult Login(LoginDTO loginData)
        {
            //Executed when Login is Clicked
            loginData.ErrorMessage = null;
            if (ModelState.IsValid)
            {
                if (loginData.LoginAsAdmin == true)
                {
                    var loginCheck = _unitOfWork.AdminAuthenticationRepository.AuthenticateAdminByCredentials(loginData.Username, loginData.Password);
                    if (loginCheck != null)
                    {
                        HttpContext.Session.SetInt32("shopId", (int)loginCheck);
                        return RedirectToAction("Index", "Dashboard");
                    }
                    else
                    {
                        loginData.ErrorMessage = "Invalid Credentials. Please try again.";
                        return View("Index", loginData);
                    }
                }
                else
                {
                    var loginCheck = _unitOfWork.UserAuthenticationRepository.AuthenticateUserByCredentials(loginData.Username, loginData.Password);
                    if (loginCheck != null)
                    {
                        HttpContext.Session.SetInt32("userId", (int)loginCheck);
                        return RedirectToAction("Index", "Listing");
                    }
                    else
                    {
                        loginData.ErrorMessage = "Invalid Credentials. Please try again.";
                        return View("Index", loginData);
                    }
                }
            }
            return View("Index", loginData);
        }

        public IActionResult RegisterUser()
        {
            //To open User Registration form
            return RedirectToAction("User", "Register");
        }
        public IActionResult RegisterShop()
        {
            //To open Shop Registration form
            return RedirectToAction("Shop", "Register");
        }
    }
}
﻿using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public DashboardController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index(int? foodCategoryId)
        {
            //Initialize and load values to DTO
            var ShopId = HttpContext.Session.GetInt32("shopId");
            if (ShopId == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                DashboardDTO dModel = new()
                {
                    ShopId = (int)ShopId,
                    Shop = _unitOfWork.ShopRepository.GetById((int)ShopId),
                    ShopServices = _unitOfWork.ShopServicesRepository.GetShopServicesByShopId((int)ShopId),
                    FoodCategories = _unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop((int)ShopId),
                    FoodItems = foodCategoryId != null ? _unitOfWork.FoodItemRepository.GetFoodItemsByCategoryId((int)ShopId, (int)foodCategoryId) : _unitOfWork.FoodItemRepository.GetFoodItemsByShopId((int)ShopId)
                };
                return View(dModel);
            }
        }
    }
}

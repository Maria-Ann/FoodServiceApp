﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Controllers
{
    public class FoodItemsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public FoodItemsController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        // GET: FoodItems/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodItem = _unitOfWork.FoodItemRepository.GetById((int)id);
            if (foodItem == null)
            {
                return NotFound();
            }

            return View(foodItem);
        }

        // GET: FoodItems/Create
        public IActionResult Create()
        {
            var shopId = HttpContext.Session.GetInt32("shopId");
            if (shopId != null)
            {
                ViewData["ShopId"] = shopId;
                ViewData["CategoryId"] = new SelectList(_unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop((int)shopId), "Id", "Name");
            }
            return View();
        }

        // POST: FoodItems/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,ShopId,Image,CategoryId,Name,Description,Price,MinQuantity,MaxQuantity,IsOutOfStock,IsVegan,IsAlcoholic")] FoodItem foodItem)
        {
            if (ModelState.IsValid)
            {
                _unitOfWork.FoodItemRepository.Add(foodItem);
                _unitOfWork.FoodItemRepository.Save();
                return RedirectToAction("Index","Dashboard");
            }
            var shopId = HttpContext.Session.GetInt32("shopId");
            if (shopId != null)
            {
                ViewData["ShopId"] = shopId;
                ViewData["CategoryId"] = new SelectList(_unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop((int)shopId), "Id", "Name");
            }
            return View(foodItem);
        }

        // GET: FoodItems/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodItem = _unitOfWork.FoodItemRepository.GetById((int)id);
            if (foodItem == null)
            {
                return NotFound();
            }
            var shopId = HttpContext.Session.GetInt32("shopId");
            if (shopId != null)
            {
                ViewData["ShopId"] = shopId;
                ViewData["CategoryId"] = new SelectList(_unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop((int)shopId), "Id", "Name");
            }
            return View(foodItem);
        }

        // POST: FoodItems/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id,ShopId,Image,CategoryId,Name,Description,Price,MinQuantity,MaxQuantity,IsOutOfStock,IsVegan,IsAlcoholic")] FoodItem foodItem)
        {
            if (id != foodItem.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _unitOfWork.FoodItemRepository.Update(foodItem);
                    _unitOfWork.FoodItemRepository.Save();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FoodItemExists(foodItem.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction("Index", "Dashboard");
            }
            var shopId = HttpContext.Session.GetInt32("shopId");
            if (shopId != null)
            {
                ViewData["ShopId"] = shopId;
                ViewData["CategoryId"] = new SelectList(_unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop((int)shopId), "Id", "Name");
            }
            return View(foodItem);
        }

        // GET: FoodItems/Delete/5
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodItem = _unitOfWork.FoodItemRepository.GetById((int)id);
            if (foodItem == null)
            {
                return NotFound();
            }

            return View(foodItem);
        }

        // POST: FoodItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            if (_unitOfWork.FoodItemRepository == null)
            {
                return Problem("Entity set 'AppDbContext.FoodItems'  is null.");
            }
            var foodItem = _unitOfWork.FoodItemRepository.GetById((int)id);
            if (foodItem != null)
            {
                _unitOfWork.FoodItemRepository.Remove(foodItem);
            }

            _unitOfWork.FoodItemRepository.Save();
            return RedirectToAction("Index", "Dashboard");
        }

        private bool FoodItemExists(int id)
        {
            return (_unitOfWork.FoodItemRepository.GetAll()?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

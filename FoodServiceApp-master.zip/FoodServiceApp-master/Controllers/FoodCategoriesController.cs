﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Controllers
{
    public class FoodCategoriesController : Controller
    {
        public readonly IUnitOfWork _unitOfWork;
        public FoodCategoriesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        // GET: FoodCategories
        public IActionResult Index()
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            return View(_unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop(shopId));
        }

        // GET: FoodCategories/Details/5
        public IActionResult Details()
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            var foodCategory = _unitOfWork.FoodCategoryRepository.GetById(shopId);
            if (foodCategory == null)
            {
                return NotFound();
            }

            return View(foodCategory);
        }

        // GET: FoodCategories/Create
        public IActionResult Create()
        {
            int shopId = HttpContext.Session.GetInt32("shopId") ?? 0;
            ViewData["shopId"] = shopId;
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,ShopId,Name,Description")] FoodCategory foodCategory)
        {
            if (ModelState.IsValid)
            {
                _unitOfWork.FoodCategoryRepository.Add(foodCategory);
                _unitOfWork.FoodCategoryRepository.Save();
                return RedirectToAction("Index","Dashboard");
            }
            return View(foodCategory);
        }

        // GET: FoodCategories/Edit/5
        public IActionResult Edit(int id)
        {
            var foodCategory = _unitOfWork.FoodCategoryRepository.GetById(id);
            if (foodCategory == null)
            {
                return NotFound();
            }
            return View(foodCategory);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id,ShopId,Name,Description")] FoodCategory foodCategory)
        {
            if (id != foodCategory.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _unitOfWork.FoodCategoryRepository.Update(foodCategory);
                    _unitOfWork.FoodCategoryRepository.Save();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FoodCategoryExists(foodCategory.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(foodCategory);
        }

        // GET: FoodCategories/Delete/5
        public IActionResult Delete(int id)
        {
            var foodCategory = _unitOfWork.FoodCategoryRepository.GetById(id);
            if (foodCategory == null)
            {
                return NotFound();
            }

            return View(foodCategory);
        }

        // POST: FoodCategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var foodCategory = _unitOfWork.FoodCategoryRepository.GetById(id);
            if (foodCategory != null)
            {
                _unitOfWork.FoodCategoryRepository.Remove(foodCategory);
            }

            _unitOfWork.FoodCategoryRepository.Save();
            return RedirectToAction(nameof(Index));
        }

        private bool FoodCategoryExists(int id)
        {
            return _unitOfWork.FoodCategoryRepository.Any(e => e.Id == id);
        }
    }
}

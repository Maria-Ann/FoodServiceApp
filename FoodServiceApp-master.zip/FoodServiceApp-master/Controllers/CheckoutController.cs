﻿using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public CheckoutController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        private CheckoutDTO? LoadUserData()
        {
            //To load data into DTO
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId == null)
            {
                return null;
            }
            else
            {
                var cartItems = _unitOfWork.CartRepository.GetCartItems((int)userId);
                var userInfo = _unitOfWork.UserDataRepository.GetById((int)userId);
                var userAddresses = _unitOfWork.AddressRepository.GetUserAddresses((int)userId).ToList();
                var selectedDelAddr = userAddresses.Where(addr => addr.IsDeliveryAddress == true).FirstOrDefault();
                var selectedBillAddr = userAddresses.Where(addr => addr.IsBillingAddress == true).FirstOrDefault();
                CheckoutDTO checkoutData = new()
                {
                    CartItems = cartItems,
                    UserInformation = userInfo,
                    UserAddresses = userAddresses,
                };
                if (selectedDelAddr != null)
                {
                    checkoutData.SelectedDeliveyAddress = selectedDelAddr;
                }
                if (selectedBillAddr != null)
                {
                    checkoutData.SelectedBillingAddress = selectedBillAddr;
                }
                if (cartItems.Count == 0)
                {
                    return null;
                }
                return checkoutData;
            }
        }
        public IActionResult Index()
        {
            //Initialize and load data into DTO
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                var userData = LoadUserData();
                if (userData == null)
                {
                    return RedirectToAction("Index", "Listing");
                }
                else
                {
                    CheckoutDTO checkoutData = userData;
                    return View(checkoutData);
                }
            }
        }
        public IActionResult SelectDeliveryAddress(int? addressId)
        {
            //Executed when user select a Delivery address
            if (addressId == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                var userAddr = _unitOfWork.AddressRepository.GetById((int)addressId);
                userAddr.IsDeliveryAddress = true;
                _unitOfWork.AddressRepository.Update(userAddr);
                _unitOfWork.AddressRepository.Save();
                return RedirectToAction("Index");
            }
        }
        public IActionResult SelectBillingAddress(int? addressId)
        {
            //Executed when user select a Billing address
            if (addressId == null)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                var userAddr = _unitOfWork.AddressRepository.GetById((int)addressId);
                userAddr.IsBillingAddress = true;
                _unitOfWork.AddressRepository.Update(userAddr);
                _unitOfWork.AddressRepository.Save();
                return RedirectToAction("Index");
            }
        }
        [HttpPost]
        public IActionResult CompleteCheckout(CheckoutValidationDTO checkoutData)
        {
            //To validate and complete checkout
            var userData = LoadUserData();
            if (ModelState.IsValid)
            {
                if(userData != null)
                {
                    userData.CartItems.ForEach(item =>
                    {
                        _unitOfWork.CartRepository.SetPlaced(item);
                    });
                }
                return RedirectToAction("Index", "Listing");
            }
            return View("Index", userData);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Controllers
{
    public class AddressesController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public AddressesController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {
            //To get user's address
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId != null)
            {
                var userAddresses = _unitOfWork.AddressRepository.GetUserAddresses((int)userId);
                return View(userAddresses);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public IActionResult Details(int? id)
        {
            //Fetch and display user's address
            if (id == null || _unitOfWork.AddressRepository == null)
            {
                return NotFound();
            }

            var address = _unitOfWork.AddressRepository.GetById((int)id);
            if (address == null)
            {
                return NotFound();
            }

            return View(address);
        }

        public IActionResult Create()
        {
            //Create new address for user
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId != null)
            {
                Address userAddress = new()
                {
                    UserId = (int)userId,
                    IsShop = false,
                };
                return View(userAddress);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,UserId,UnitAddress,City,Country,PostalCode,IsBillingAddress,IsDeliveryAddress,IsShop")] Address address)
        {
            //Create POST method
            if (ModelState.IsValid)
            {
                _unitOfWork.AddressRepository.Add(address);
                _unitOfWork.AddressRepository.Save();
                return RedirectToAction(nameof(Index));
            }
            return View(address);
        }

        // GET: Addresses/Edit/5
        public IActionResult Edit(int? id)
        {
            //Fetching data to edit existing address
            if (id == null || _unitOfWork.AddressRepository == null)
            {
                return NotFound();
            }

            var address = _unitOfWork.AddressRepository.GetById((int)id);
            if (address == null)
            {
                return NotFound();
            }
            return View(address);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id,UserId,UnitAddress,City,Country,PostalCode,IsBillingAddress,IsDeliveryAddress,IsShop")] Address address)
        {
            //POST to update the address
            if (id != address.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _unitOfWork.AddressRepository.Update(address);
                    _unitOfWork.AddressRepository.Save();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AddressExists(address.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(address);
        }

        public IActionResult Delete(int? id)
        {
            //Fetch the address to be deleted
            if (id == null || _unitOfWork.AddressRepository == null)
            {
                return NotFound();
            }

            var address = _unitOfWork.AddressRepository.GetById((int)id);
            if (address == null)
            {
                return NotFound();
            }

            return View(address);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            //POST to delete the address
            if (_unitOfWork.AddressRepository == null)
            {
                return Problem("Entity set 'AppDbContext.Addresses'  is null.");
            }
            var address = _unitOfWork.AddressRepository.GetById(id);
            if (address != null)
            {
                _unitOfWork.AddressRepository.Remove(address);
            }

            _unitOfWork.AddressRepository.Save();
            return RedirectToAction(nameof(Index));
        }

        private bool AddressExists(int id)
        {
            //To validate if address is present
            return (_unitOfWork.AddressRepository.GetAll()?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}

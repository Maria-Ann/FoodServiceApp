﻿using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Reflection;

namespace FoodServiceApp.Controllers
{
    public class ListingController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        public ListingController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IActionResult Index(int? selectedShopId, int? selectedCategoryId)
        {
            //Initialize and load values to DTO
            int userId = HttpContext.Session.GetInt32("userId") ?? 0;
            var shopsList = _unitOfWork.ShopRepository.GetAll();
            var cartCount = _unitOfWork.CartRepository.GetCartItems(userId).Count();
            var ordersPlaced = _unitOfWork.CartRepository.GetPlacedOrders(userId).Count();
            var confirmedOrders = _unitOfWork.CartRepository.GetConfirmedOrders(userId).Count();
            var shippedOrders = _unitOfWork.CartRepository.GetShippedOrders(userId).Count();
            var receivedOrders = _unitOfWork.CartRepository.GetDeliveredOrders(userId).Count();
            List<ListingDTO> listings = new List<ListingDTO>();
            foreach (var shop in shopsList)
            {
                ListingDTO listItem = new()
                {
                    shop = shop,
                    shopServices = _unitOfWork.ShopServicesRepository.GetShopServicesByShopId(shop.Id),
                    shopAddress = _unitOfWork.AddressRepository.GetShopAddresses(shop.Id).FirstOrDefault(),
                    foodCategories = _unitOfWork.FoodCategoryRepository.GetFoodCategoriesForShop(shop.Id),
                    foodItems = selectedShopId != null && selectedCategoryId != null && selectedShopId == shop.Id ? _unitOfWork.FoodItemRepository.GetFoodItemsByCategoryId(shop.Id, (int)selectedCategoryId) : _unitOfWork.FoodItemRepository.GetFoodItemsByShopId(shop.Id)
                };
                listings.Add(listItem);
            }

            UserListingPageDTO UserListingPageDTO = new()
            {
                UserInfo = _unitOfWork.UserDataRepository.GetById(userId),
                Listing = listings,
                CartCount = cartCount,
                OrdersConfirmed = confirmedOrders,
                OrdersPlaced = ordersPlaced,
                OrdersShipped = shippedOrders,
                OrdersReceived = receivedOrders,
                CartItems = _unitOfWork.CartRepository.GetCartItems(userId),
                PlacedItems = _unitOfWork.CartRepository.GetPlacedOrders(userId),
                ConfirmedItems = _unitOfWork.CartRepository.GetConfirmedOrders(userId),
                ShippedItems = _unitOfWork.CartRepository.GetShippedOrders(userId),
                DeliveredItems = _unitOfWork.CartRepository.GetDeliveredOrders(userId),
                CartTotal = _unitOfWork.CartRepository.CartTotal(userId),
                PlacedTotal = _unitOfWork.CartRepository.PlacedTotal(userId),
                ConfirmedTotal = _unitOfWork.CartRepository.ConfirmedTotal(userId),
                ShippedTotal = _unitOfWork.CartRepository.ShippedTotal(userId),
                DeliveredTotal = _unitOfWork.CartRepository.DeliveredTotal(userId),
            };
            return View(UserListingPageDTO);
        }

        public IActionResult AddToCart(int shopId, int foodItemId)
        {
            //Add item to Cart
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId != null)
            {
                Cart cartItem = new()
                {
                    UserId = (int)userId,
                    ShopId = shopId,
                    FoodItemId = foodItemId,
                    IsOrderPlaced = false,
                    IsOrderConfirmed = false,
                    IsOrderShipped = false,
                    IsOrderReceived = false,
                };
                _unitOfWork.CartRepository.Add(cartItem);
                _unitOfWork.CartRepository.Save();
            }
            return RedirectToAction("Index");
        }
        public IActionResult DeleteCartItem(int cartItemId)
        {
            //Delete item in Cart
            var userId = HttpContext.Session.GetInt32("userId");
            if (userId != null)
            {
                var cartItem = _unitOfWork.CartRepository.GetById(cartItemId);
                _unitOfWork.CartRepository.Remove(cartItem);
                _unitOfWork.CartRepository.Save();
            }
            return RedirectToAction("Index");
        }
    }
}

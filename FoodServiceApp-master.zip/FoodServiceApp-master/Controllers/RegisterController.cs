﻿using FoodServiceApp.Models;
using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;

namespace FoodServiceApp.Controllers
{
    public class RegisterController : Controller
    {
        public readonly IUnitOfWork _unitOfWork;
        public RegisterController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        [HttpGet]
        public new IActionResult User()
        {
            ViewData["isShop"] = false;
            ViewData["IsBillingAddress"] = true;
            ViewData["IsDeliveryAddress"] = true;
            return View();
        }
        [HttpGet]
        public IActionResult Shop()
        {
            ViewData["isShop"] = true;
            ViewData["IsBillingAddress"] = true;
            ViewData["IsDeliveryAddress"] = true;
            return View();
        }
        [HttpPost]
        [Route("/[controller]/[action]")]
        public IActionResult RegisterUser(UserRegistrationDTO udata)
        {
            ViewData["isShop"] = false;
            ViewData["IsBillingAddress"] = true;
            ViewData["IsDeliveryAddress"] = true;
            if (ModelState.IsValid)
            {
                if (udata.Password == udata.ConfirmPassword)
                {
                    UserData userData = new UserData { Email = udata.Email, Name = udata.Name, Phone = udata.PhoneNumber };
                    var validateUser = _unitOfWork.UserDataRepository.ValidateNewUser(userData);
                    if (validateUser)
                    {
                        _unitOfWork.UserDataRepository.Add(userData);
                        _unitOfWork.UserDataRepository.Save();
                        int? userId = _unitOfWork.UserDataRepository.GetUserIdFromEmail(udata.Email);
                        if (userId != null && userId > 0)
                        {
                            UserAuthentication authData = new() { UserId = (int)userId, Username = udata.Username, Password = udata.Password };
                            _unitOfWork.UserAuthenticationRepository.CreateNewCredentials(authData);
                            udata.DeliveryAddress.UserId = (int)userId;
                            udata.DeliveryAddress.IsDeliveryAddress = true;
                            udata.DeliveryAddress.IsBillingAddress = true;
                            udata.DeliveryAddress.IsShop = false;
                            _unitOfWork.UserAuthenticationRepository.Save();
                            _unitOfWork.AddressRepository.Add(udata.DeliveryAddress);
                            _unitOfWork.AddressRepository.Save();
                            return RedirectToAction("Index","Home");
                        }
                        else
                        {
                            return View("User",udata);
                        }
                    }
                    else
                    {
                        return View("User", udata);
                    }
                }
                else
                {
                    return View("User", udata);
                }
            }
            else
            {
                return View("User", udata);
            }

        }
        [HttpPost]
        [Route("/[controller]/[action]")]
        public IActionResult RegisterShop(ShopRegistrationDTO sdata)
        {
            ViewData["isShop"] = true;
            ViewData["IsBillingAddress"] = true;
            ViewData["IsDeliveryAddress"] = true;
            if (ModelState.IsValid)
            {
                if (sdata.Password == sdata.ConfirmPassword)
                {
                    Shop shopData = new() { Email = sdata.Email, Name = sdata.Name, Phone = sdata.PhoneNumber };
                    var validateShop = _unitOfWork.ShopRepository.ValidateNewShop(shopData);
                    if (validateShop)
                    {
                        _unitOfWork.ShopRepository.CreateShop(shopData);
                        _unitOfWork.ShopRepository.Save();
                        int? userId = _unitOfWork.ShopRepository.GetShopIdFromEmail(sdata.Email);
                        if (userId != null && userId > 0)
                        {
                            AdminAuthentication authData = new() { ShopId = (int)userId, Username = sdata.Username, Password = sdata.Password };
                            _unitOfWork.AdminAuthenticationRepository.CreateNewCredentials(authData);
                            sdata.ShopAddress.UserId = (int)userId;
                            sdata.ShopAddress.IsDeliveryAddress = true;
                            sdata.ShopAddress.IsBillingAddress = true;
                            sdata.ShopAddress.IsShop = true;
                            _unitOfWork.AddressRepository.Add(sdata.ShopAddress);
                            _unitOfWork.UserAuthenticationRepository.Save();
                            _unitOfWork.AddressRepository.Save();
                            return RedirectToAction("Index", "Home");
                        }
                        else
                        {
                            return View("Shop",sdata);
                        }
                    }
                    else
                    {
                        return View("Shop", sdata);
                    }
                }
                else
                {
                    return View("Shop", sdata);
                }
            }
            else
            {
                return View("Shop", sdata);
            }
        }
    }
}

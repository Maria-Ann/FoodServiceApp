﻿using FoodServiceApp.Models.DomainModels.Abstract;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Security.Cryptography;

namespace FoodServiceApp.Models.Repositories
{
    public class AdminAuthenticationRepository : GenericRepository<AdminAuthentication>, IAdminAuthentication
    {
        public AdminAuthenticationRepository(AppDbContext ctx) : base(ctx) { }
        private static string HashPassword(string password)
        {
            byte[] salt = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            int iterations = 10000;

            string hashedPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: iterations,
                numBytesRequested: 256 / 8));

            string storedPassword = $"{Convert.ToBase64String(salt)}:{iterations}:{hashedPassword}";

            return storedPassword;
        }

        private static bool VerifyPassword(string password, string storedPassword)
        {
            string[] parts = storedPassword.Split(':');
            byte[] salt = Convert.FromBase64String(parts[0]);
            int iterations = int.Parse(parts[1]);
            string hashedPassword = parts[2];

            string hashedInputPassword = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: iterations,
                numBytesRequested: 256 / 8));

            return hashedInputPassword == hashedPassword;
        }
        private static bool ValidateNotNullOrEmpty(string data)
        {
            if (string.IsNullOrWhiteSpace(data.Trim()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void CreateNewCredentials(AdminAuthentication authData)
        {
            var hashedPassword = HashPassword(authData.Password);
            authData.Password = hashedPassword;
            _context.AdminAuthentication.Add(authData);
        }

        public int? AuthenticateAdminByCredentials(string username, string password)
        {
            var userData = _context.AdminAuthentication.Where(user => user.Username == username).FirstOrDefault();
            if (userData != null && VerifyPassword(password, userData.Password) == true)
            {
                return userData.ShopId;
            }
            else
            {
                return null;
            }
        }

        public bool ValidateNewCredentials(AdminAuthentication authData)
        {
            if (ValidateNotNullOrEmpty(authData.ShopId.ToString()) && ValidateNotNullOrEmpty(authData.Username) && ValidateNotNullOrEmpty(authData.Password))
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}

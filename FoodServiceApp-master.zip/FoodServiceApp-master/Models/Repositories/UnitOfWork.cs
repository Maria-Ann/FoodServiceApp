﻿using FoodServiceApp.Models.DomainModels.Abstract;
using FoodServiceApp.Models.DomainModels;

namespace FoodServiceApp.Models.Repositories
{
    public class UnitOfWork: IUnitOfWork
    {
        private readonly AppDbContext _context;
        public UnitOfWork(AppDbContext ctx) {
            _context = ctx;
            AddressRepository = new AddressRepository(_context);
            AdminAuthenticationRepository = new AdminAuthenticationRepository(_context);
            CartRepository = new CartRepository(_context);
            FoodCategoryRepository = new FoodCategoryRepository(_context);
            FoodItemRepository = new FoodItemRepository(_context);
            ShopRepository = new ShopRepository(_context);
            ShopServicesRepository = new ShopServicesRepository(_context);
            UserAuthenticationRepository = new UserAuthenticationRepository(_context);
            UserDataRepository = new UserDataRepository(_context);
        }

        public IAddress AddressRepository { get; private set; }

        public IAdminAuthentication AdminAuthenticationRepository { get; private set; }

        public ICart CartRepository { get; private set; }

        public IFoodCategory FoodCategoryRepository { get; private set; }

        public IFoodItem FoodItemRepository { get; private set; }

        public IShop ShopRepository { get; private set; }

        public IShopServices ShopServicesRepository { get; private set; }

        public IUserAuthentication UserAuthenticationRepository { get; private set; }

        public IUserData UserDataRepository { get; private set; }

        public void Dispose()
        {
            _context.Dispose();
        }

        public int Save()
        {
            return _context.SaveChanges();
        }
    }
}

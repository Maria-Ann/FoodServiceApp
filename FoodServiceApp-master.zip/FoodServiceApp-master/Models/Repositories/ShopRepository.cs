﻿using FoodServiceApp.Models.DomainModels.Abstract;

namespace FoodServiceApp.Models.Repositories
{
    public class ShopRepository:GenericRepository<Shop>,IShop
    {
        public ShopRepository(AppDbContext ctx) : base(ctx) { }
        private static bool ValidateNotNullOrEmpty(string data)
        {
            if (string.IsNullOrWhiteSpace(data.Trim()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void CreateShop(Shop shopData)
        {
            _context.Shops.Add(shopData);
        }

        public int? GetShopIdFromEmail(string email)
        {
            var sdata = _context.Shops.Where(user => user.Email == email).FirstOrDefault();
            return sdata?.Id;
        }

        public bool ValidateNewShop(Shop shopData)
        {
            if (ValidateNotNullOrEmpty(shopData.Email) || ValidateNotNullOrEmpty(shopData.Email) || ValidateNotNullOrEmpty(shopData.Phone) || _context.Shops.Where(u => u.Email.Trim() == shopData.Email).Count() > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}

﻿using FoodServiceApp.Models.DomainModels.Abstract;

namespace FoodServiceApp.Models.Repositories
{
    public class FoodCategoryRepository : GenericRepository<FoodCategory>, IFoodCategory
    {
        public FoodCategoryRepository(AppDbContext ctx) : base(ctx) { }

        public List<FoodCategory> GetFoodCategoriesForShop(int ShopId)
        {
            return _context.FoodCategories.Where(c => c.ShopId == ShopId).ToList();
        }
    }
}

﻿using FoodServiceApp.Models.DomainModels.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Models.Repositories
{
    public class UserDataRepository : GenericRepository<UserData>, IUserData
    {
        public UserDataRepository(AppDbContext ctx) : base(ctx) { }
        private static bool ValidateNotNullOrEmpty(string data)
        {
            if (string.IsNullOrWhiteSpace(data.Trim()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void CreateUser(UserData userData)
        {
            _context.UserData.Add(userData);
        }

        public int? GetUserIdFromEmail(string email)
        {
            var udata = _context.UserData.Where(user => user.Email == email).FirstOrDefault();
            return udata?.Id;
        }

        public bool ValidateNewUser(UserData userData)
        {
            if (ValidateNotNullOrEmpty(userData.Email) || ValidateNotNullOrEmpty(userData.Email) || ValidateNotNullOrEmpty(userData.Phone) || _context.UserData.Where(u => u.Email.Trim() == userData.Email).Count() > 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}

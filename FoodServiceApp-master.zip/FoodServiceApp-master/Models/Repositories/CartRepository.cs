﻿using FoodServiceApp.Models.DomainModels.Abstract;
using Microsoft.EntityFrameworkCore;

namespace FoodServiceApp.Models.Repositories
{
    public class CartRepository : GenericRepository<Cart>, ICart
    {
        public CartRepository(AppDbContext context) : base(context) { }

        public List<Cart> GetCartItems(int userId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.UserId == userId && c.IsOrderPlaced == false).Include(c => c.FoodItem).ThenInclude(c => c.Shop).ToList();
            return foodItems;
        }
        public List<Cart> GetPlacedOrders(int userId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.UserId == userId && c.IsOrderPlaced == true && c.IsOrderConfirmed == false).Include(c => c.FoodItem).ThenInclude(c => c.Shop).ToList();
            return foodItems;
        }

        public List<Cart> GetConfirmedOrders(int userId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.UserId == userId && c.IsOrderShipped == false && c.IsOrderConfirmed == true).Include(c => c.FoodItem).ThenInclude(c => c.Shop).ToList();
            return foodItems;
        }
        public List<Cart> GetShippedOrders(int userId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.UserId == userId && c.IsOrderReceived == false && c.IsOrderShipped == true).Include(c => c.FoodItem).ThenInclude(c => c.Shop).ToList();
            return foodItems;
        }
        public List<Cart> GetDeliveredOrders(int userId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.UserId == userId && c.IsOrderReceived == true).Include(c => c.FoodItem).ThenInclude(c => c.Shop).ToList();
            return foodItems;
        }

        public void SetPlaced(Cart cartItem)
        {
            cartItem.IsOrderPlaced = true;
            _context.Update(cartItem);
            _context.SaveChanges();
        }

        public void SetConfirmed(Cart cartItem)
        {
            cartItem.IsOrderConfirmed = true;
            _context.Update(cartItem);
            _context.SaveChanges();
        }
        public void SetShipped(Cart cartItem)
        {
            cartItem.IsOrderShipped = true;
            _context.Update(cartItem);
            _context.SaveChanges();
        }
        public void SetDelivered(Cart cartItem)
        {
            cartItem.IsOrderReceived = true;
            _context.Update(cartItem);
            _context.SaveChanges();
        }

        public decimal CartTotal(int userId)
        {
            decimal total = _context.Carts.Where(c => c.UserId == userId && c.IsOrderPlaced == false).Include(c => c.FoodItem).Sum(s => s.FoodItem.Price);
            return total;
        }

        public decimal PlacedTotal(int userId)
        {
            decimal total = _context.Carts.Where(c => c.UserId == userId && c.IsOrderPlaced == true && c.IsOrderConfirmed == false).Include(c => c.FoodItem).Sum(s => s.FoodItem.Price);
            return total;
        }

        public decimal ConfirmedTotal(int userId)
        {
            decimal total = _context.Carts.Where(c => c.UserId == userId && c.IsOrderConfirmed == true && c.IsOrderShipped == false).Include(c => c.FoodItem).Sum(s => s.FoodItem.Price);
            return total;
        }

        public decimal ShippedTotal(int userId)
        {
            decimal total = _context.Carts.Where(c => c.UserId == userId && c.IsOrderShipped == true && c.IsOrderReceived == false).Include(c => c.FoodItem).Sum(s => s.FoodItem.Price);
            return total;
        }

        public decimal DeliveredTotal(int userId)
        {
            decimal total = _context.Carts.Where(c => c.UserId == userId && c.IsOrderReceived == true).Include(c => c.FoodItem).Sum(s => s.FoodItem.Price);
            return total;
        }

        public List<Cart> GetShopOrders(int shopId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.ShopId == shopId && c.IsOrderPlaced == true && c.IsOrderConfirmed == false).Include(c => c.FoodItem).Include(c => c.UserInfo).ToList();
            return foodItems;
        }

        public List<Cart> GetShopConfirmedOrders(int shopId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.ShopId == shopId && c.IsOrderShipped == false && c.IsOrderConfirmed == true).Include(c => c.FoodItem).Include(c => c.UserInfo).ToList();
            return foodItems;
        }

        public List<Cart> GetShopShippedOrders(int shopId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.ShopId == shopId && c.IsOrderReceived == false && c.IsOrderShipped == true).Include(c => c.FoodItem).Include(c => c.UserInfo).ToList();
            return foodItems;
        }

        public List<Cart> GetShopDeliveredOrders(int shopId)
        {
            List<Cart> foodItems = _context.Carts.Where(c => c.ShopId == shopId && c.IsOrderReceived == true).Include(c => c.FoodItem).Include(c => c.UserInfo).ToList();
            return foodItems;
        }
    }
}

﻿using FoodServiceApp.Models.DomainModels.Abstract;

namespace FoodServiceApp.Models.Repositories
{
    public interface IUnitOfWork :IDisposable
    {
        IAddress AddressRepository { get; }
        IAdminAuthentication AdminAuthenticationRepository { get; }
        ICart CartRepository { get; }
        IFoodCategory FoodCategoryRepository { get; }
        IFoodItem FoodItemRepository { get; }
        IShop ShopRepository { get; }
        IShopServices ShopServicesRepository { get; }
        IUserAuthentication UserAuthenticationRepository { get; }
        IUserData UserDataRepository { get; }
        int Save();

    }
}

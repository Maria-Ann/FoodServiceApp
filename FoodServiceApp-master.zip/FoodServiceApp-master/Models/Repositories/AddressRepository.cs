﻿using FoodServiceApp.Models.DomainModels.Abstract;

namespace FoodServiceApp.Models.Repositories
{
    public class AddressRepository : GenericRepository<Address>, IAddress
    {
        public AddressRepository(AppDbContext ctx) : base(ctx) { }
        public new void Add(Address address)
        {
            var currentUserAddresses = _context.Addresses.Where(addr => addr.UserId == address.UserId).ToList();
            foreach (var currentAddress in currentUserAddresses)
            {
                if (address.IsBillingAddress == true)
                {
                    currentAddress.IsBillingAddress = false;
                }
                if (address.IsDeliveryAddress == true)
                {
                    currentAddress.IsDeliveryAddress = false;
                }
                _context.Addresses.Update(currentAddress);
            }
            _context.Add(address);
            _context.SaveChanges();
        }
        public new void Update(Address address)
        {
            var currentUserAddresses = _context.Addresses.Where(addr => addr.UserId == address.UserId && addr.Id != address.Id).ToList();
            foreach (var currentAddress in currentUserAddresses)
            {
                if (address.IsBillingAddress == true)
                {
                    currentAddress.IsBillingAddress = false;
                }
                if (address.IsDeliveryAddress == true)
                {
                    currentAddress.IsDeliveryAddress = false;
                }
                _context.Addresses.Update(currentAddress);
            }
            _context.Update(address);
            _context.SaveChanges();
        }

        public Address GetBillingAddress(int userId)
        {
            var billingAddress = _context.Addresses.Where(address => address.UserId == userId && address.IsBillingAddress == true).FirstOrDefault();
            return billingAddress;
        }

        public Address GetDeliveryAddress(int userId)
        {
            var deliveryAddress = _context.Addresses.Where(address => address.UserId == userId && address.IsDeliveryAddress == true).FirstOrDefault();
            return deliveryAddress;
        }

        public IEnumerable<Address> GetUserAddresses(int userId)
        {
            var addresses = _context.Addresses.Where(address => address.UserId == userId && address.IsShop == false).ToList();
            return addresses;
        }

        public IEnumerable<Address> GetShopAddresses(int userId)
        {
            var addresses = _context.Addresses.Where(address => address.UserId == userId && address.IsDeliveryAddress == true && address.IsShop == true).ToList();
            return addresses;
        }

        public void RegisterNewAddress(Address address, bool isDeliveryAddress, bool isBillingAddress)
        {
            address.IsDeliveryAddress = isDeliveryAddress;
            address.IsBillingAddress = isBillingAddress;
            _context.Addresses.Add(address);
        }
    }
}

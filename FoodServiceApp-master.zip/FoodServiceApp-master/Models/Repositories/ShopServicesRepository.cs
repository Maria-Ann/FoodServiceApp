﻿using FoodServiceApp.Models.DomainModels.Abstract;

namespace FoodServiceApp.Models.Repositories
{
    public class ShopServicesRepository : GenericRepository<ShopServices>, IShopServices
    {
        public ShopServicesRepository(AppDbContext ctx) : base(ctx) { }

        public ShopServices GetShopServicesByShopId(int shopId)
        {
            return _context.Services.Where(s => s.ShopId == shopId).FirstOrDefault();
        }
    }
}

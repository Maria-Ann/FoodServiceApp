﻿using FoodServiceApp.Models.DomainModels.Abstract;
using Microsoft.EntityFrameworkCore;

namespace FoodServiceApp.Models.Repositories
{
    public class FoodItemRepository : GenericRepository<FoodItem>, IFoodItem
    {
        public FoodItemRepository(AppDbContext ctx) : base(ctx) { }
        public new FoodItem? GetById(int id)
        {
            FoodItem? item = _context.FoodItems.Where(f => f.Id == id).Include(f => f.Category).FirstOrDefault();
            return item;
        }
        public List<FoodItem> GetFoodItemsByCategoryId(int shopId, int categoryId)
        {
            List<FoodItem> foodItems = _context.FoodItems.Where(f => f.ShopId == shopId && f.CategoryId == categoryId).ToList();
            return foodItems;
        }

        public List<FoodItem> GetFoodItemsByShopId(int shopId)
        {
            List<FoodItem> foodItems = _context.FoodItems.Where(f => f.ShopId == shopId).ToList();
            return foodItems;
        }
    }
}

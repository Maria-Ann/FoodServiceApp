﻿using System.Linq.Expressions;

namespace FoodServiceApp.Models.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        public readonly AppDbContext _context;
        public GenericRepository(AppDbContext ctx)
        {
            _context = ctx;
        }
        public void Add(T entity)
        {
            try
            {
                _context.Set<T>().Add(entity);
            }
            catch
            {
                throw;
            }
        }

        public void AddRange(IEnumerable<T> entities)
        {
            try
            {
                _context.Set<T>().AddRange(entities);
            }
            catch
            {
                throw;
            }
        }

        public bool Any(Expression<Func<T, bool>> predicate)
        {
            return _context.Set<T>().Any(predicate);
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> predicate)
        {
            return _context.Set<T>().Where(predicate);
        }

        public IEnumerable<T> GetAll()
        {
            return _context.Set<T>().ToList();
        }

        public T GetById(int id)
        {
            return _context.Set<T>().Find(id);
        }

        public void Remove(T entity)
        {
            try
            {
                _context.Set<T>().Remove(entity);
            }
            catch
            {
                throw;
            }
        }

        public void RemoveRange(IEnumerable<T> entities)
        {
            try
            {
            _context.Set<T>().RemoveRange(entities);
            }
            catch
            {
                throw;
            }
        }

        public void Save()
        {
            _context.SaveChanges();
        }

        public void Update(T entity)
        {
            _context.Update(entity);
        }
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Models
{
    public class Cart
    {
        public int Id { get; set; }
        [ForeignKey("UserInfo")]
        public int UserId { get; set; }
        public UserData? UserInfo { get; set; }
        public int ShopId { get; set; }
        public bool? IsOrderPlaced { get; set; }
        public bool? IsOrderConfirmed { get; set; }
        public bool? IsOrderShipped { get; set; }
        public bool? IsOrderReceived { get; set; }
        [ForeignKey("FoodItem")]
        public int FoodItemId { get; set; }
        public FoodItem? FoodItem { get; set; }

    }
}

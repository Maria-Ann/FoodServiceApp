﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace FoodServiceApp.Models
{
    public class UserData
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please enter your Name")]
        [DisplayName("Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter your Email")]
        [DisplayName("Email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please enter your Phone Number")]
        [DisplayName("Phone")]
        [MaxLength(12)]
        public string Phone { get; set; }

    }
}

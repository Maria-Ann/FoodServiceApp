﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Models
{
    public class ShopServices
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public int ShopId { get; set; }
        [DisplayName("Is the shop still Active?")]
        public bool IsActive { get; set; }
        [DisplayName("Do you serve Vegen food?")]
        public bool ServesVegan { get; set; }
        [DisplayName("Do you serve Non-Vegan food?")]
        public bool ServesNonVeg { get; set; }
        [DisplayName("Do you serve Alcohol?")]
        public bool ServesAlcohol { get; set; }
        [DisplayName("Do you have Alcohol Delivery?")]
        public bool DeliversAlcohol { get; set; }
    }
}

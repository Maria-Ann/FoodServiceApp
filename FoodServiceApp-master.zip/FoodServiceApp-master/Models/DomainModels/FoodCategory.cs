﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace FoodServiceApp.Models
{
    public class FoodCategory
    {
        public int Id { get; set; }
        public int ShopId { get; set; }
        [Required(ErrorMessage = "Please enter a Category Name")]
        [DisplayName("Category Name")]
        public string Name { get; set; }
        [DisplayName("Category Description")]
        public string? Description { get; set; }
    }
}

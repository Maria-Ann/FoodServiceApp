﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Models
{
    public class FoodItem
    {
        public int Id { get; set; }
        [ForeignKey("Shop")]
        public int ShopId { get; set; }
        public Shop? Shop { get; set; }
        [Required(ErrorMessage = "Please add an Image for the Food Item")]
        [DisplayName("Image")]
        public string Image { get; set; }
        [ForeignKey("Category")]
        [DisplayName("Food Category")]
        public int CategoryId { get; set; }
        public FoodCategory? Category { get; set; }
        [Required(ErrorMessage = "Please enter the Name of Food item")]
        [DisplayName("Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please enter a description for the Food item")]
        [DisplayName("Description")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Please enter a Price for the Food item")]
        [DisplayName("Price")]
        [Range(0.5,int.MaxValue,ErrorMessage = "The price should be at least $0.5")]
        public decimal Price { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "The Minimum Quantity should be at least 1")]
        public int? MinQuantity { get; set; }
        [Range(1, int.MaxValue, ErrorMessage = "The Maximum Quantity should be at least 1")]
        public int? MaxQuantity { get; set; }
        [DisplayName("Is Out of Stock")]
        public bool IsOutOfStock { get; set; }
        [DisplayName("Is Vegan?")]
        public bool IsVegan { get; set; }
        [DisplayName("Is Alcoholic?")]
        public bool IsAlcoholic { get; set; }

    }
}

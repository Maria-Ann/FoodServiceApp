﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IShopServices:IGenericRepository<ShopServices>
    {
        ShopServices GetShopServicesByShopId(int shopId);
    }
}

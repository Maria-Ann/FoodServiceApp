﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IAddress:IGenericRepository<Address>
    {
        IEnumerable<Address> GetUserAddresses(int userId);
        IEnumerable<Address> GetShopAddresses(int shopId);
        Address GetDeliveryAddress(int userId);
        Address GetBillingAddress(int userId);
        void RegisterNewAddress(Address address, bool isDeliveryAddress, bool isBillingAddress);
    }
}

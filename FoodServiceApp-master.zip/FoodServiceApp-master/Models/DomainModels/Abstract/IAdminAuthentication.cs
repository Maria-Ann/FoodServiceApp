﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IAdminAuthentication: IGenericRepository<AdminAuthentication>
    {
        bool ValidateNewCredentials(AdminAuthentication authData);
        void CreateNewCredentials(AdminAuthentication authData);
        int? AuthenticateAdminByCredentials(string username, string password);
    }
}

﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IFoodCategory:IGenericRepository<FoodCategory>
    {
        List<FoodCategory> GetFoodCategoriesForShop(int ShopId);
    }
}

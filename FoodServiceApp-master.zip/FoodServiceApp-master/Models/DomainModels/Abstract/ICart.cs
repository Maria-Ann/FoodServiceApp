﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface ICart:IGenericRepository<Cart>
    {
        List<Cart> GetCartItems(int userId);
        List<Cart> GetPlacedOrders(int userId);
        List<Cart> GetConfirmedOrders(int userId);
        List<Cart> GetShippedOrders(int userId);
        List<Cart> GetDeliveredOrders(int userId);
        List<Cart> GetShopOrders(int shopId);
        List<Cart> GetShopConfirmedOrders(int shopId);
        List<Cart> GetShopShippedOrders(int shopId);
        List<Cart> GetShopDeliveredOrders(int shopId);
        void SetPlaced(Cart cartItem);
        void SetConfirmed(Cart cartItem);
        void SetShipped(Cart cartItem);
        void SetDelivered(Cart cartItem);
        decimal CartTotal(int userId);
        decimal PlacedTotal(int userId);
        decimal ConfirmedTotal(int userId);
        decimal ShippedTotal(int userId);   
        decimal DeliveredTotal(int userId);
    }
}

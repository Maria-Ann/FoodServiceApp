﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IShop: IGenericRepository<Shop>
    {
        bool ValidateNewShop(Shop shopData);
        void CreateShop(Shop shopData);
        int? GetShopIdFromEmail(string email);
    }
}

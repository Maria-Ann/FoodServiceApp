﻿using FoodServiceApp.Models.Repositories;
namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IUserAuthentication:IGenericRepository<UserAuthentication>
    {
        bool ValidateNewCredentials(UserAuthentication authData);
        void CreateNewCredentials(UserAuthentication authData);
        int? AuthenticateUserByCredentials(string username, string password);

    }
}

﻿using FoodServiceApp.Models.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IUserData : IGenericRepository<UserData>
    {
        bool ValidateNewUser(UserData userData);
        void CreateUser(UserData userData);
        int? GetUserIdFromEmail(string email);
    }
}

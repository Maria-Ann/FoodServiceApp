﻿using FoodServiceApp.Models.Repositories;

namespace FoodServiceApp.Models.DomainModels.Abstract
{
    public interface IFoodItem:IGenericRepository<FoodItem>
    {
        FoodItem? GetById(int id);
        List<FoodItem> GetFoodItemsByCategoryId(int shopId, int categoryId);
        List<FoodItem> GetFoodItemsByShopId(int shopId);

    }
}

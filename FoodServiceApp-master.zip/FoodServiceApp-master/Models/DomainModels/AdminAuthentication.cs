﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace FoodServiceApp.Models
{
    public class AdminAuthentication
    {
        public int Id { get; set; }
        public int ShopId { get; set; }
        [Required(ErrorMessage = "Please enter the Username")]
        [DisplayName("Username")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Please enter the Password")]
        [DisplayName("Password")]
        public string Password { get; set; }
    }
}

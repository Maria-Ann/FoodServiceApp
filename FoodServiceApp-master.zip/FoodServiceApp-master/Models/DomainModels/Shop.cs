﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FoodServiceApp.Models
{
    public class Shop
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please enter the Shop's Name")]
        [MaxLength(200)]
        [DisplayName("Your Shop's Name")]
        public string Name { get; set; }
        [MaxLength(350)]
        [DisplayName("About your Shop")]
        public string? Description { get; set; }
        [Required(ErrorMessage = "Please enter the Shop's Email")]
        [MaxLength(200)]
        [DisplayName("Email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please enter the Shop's Phone number")]
        [MaxLength(200)]
        [DisplayName("Phone number")]
        public string Phone { get; set; }
    }
}

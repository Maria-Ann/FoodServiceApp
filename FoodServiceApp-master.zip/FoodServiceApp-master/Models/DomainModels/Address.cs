﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace FoodServiceApp.Models
{
    public class Address
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        [Required(ErrorMessage = "Please enter the Address")]
        [DisplayName("Address")]
        public string UnitAddress { get; set; }
        [Required(ErrorMessage = "Please enter the City")]
        [DisplayName("City")]
        public string City { get; set; }
        [Required(ErrorMessage = "Please enter the Country")]
        [DisplayName("Country")]
        public string Country { get; set; }
        [Required(ErrorMessage = "Please enter the PostalCode")]
        [DisplayName("PostalCode")]
        public string PostalCode { get; set; }
        [DisplayName("Set as Billing Address")]
        public bool IsBillingAddress { get; set; }
        [DisplayName("Set as Delivery Address")]
        public bool IsDeliveryAddress { get; set; }
        public bool IsShop { get; set; }
    }
}

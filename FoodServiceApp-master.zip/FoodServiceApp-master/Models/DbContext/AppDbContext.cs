﻿using Microsoft.EntityFrameworkCore;

namespace FoodServiceApp.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<UserData> UserData { get; set; }
        public DbSet<UserAuthentication> UserAuthentication { get; set; }
        public DbSet<Shop> Shops { get; set; }
        public DbSet<ShopServices> Services { get; set; }
        public DbSet<FoodCategory> FoodCategories { get; set; }
        public DbSet<FoodItem> FoodItems { get; set; }
        public DbSet<AdminAuthentication> AdminAuthentication { get; set; }
        public DbSet<Cart> Carts { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FoodItem>().Property(f => f.Price).HasColumnType("decimal(18,2)");
        }
    }
}

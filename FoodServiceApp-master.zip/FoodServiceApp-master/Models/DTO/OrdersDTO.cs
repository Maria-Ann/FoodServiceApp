﻿namespace FoodServiceApp.Models
{
    public class OrdersDTO
    {
        public List<Cart> OrdersList { get; set; }
        public List<Cart> ConfirmedList { get; set; }
        public List<Cart> ShippedList { get; set; }
        public List<Cart> DeliveredList { get; set; }
    }
}

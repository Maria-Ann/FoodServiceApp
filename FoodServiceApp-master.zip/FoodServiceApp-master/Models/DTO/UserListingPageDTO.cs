﻿namespace FoodServiceApp.Models
{
    public class UserListingPageDTO
    {
        public UserData UserInfo { get; set; }
        public List<Cart>? CartItems { get; set; }
        public List<Cart>? PlacedItems { get; set; }
        public List<Cart>? ConfirmedItems { get; set; }
        public List<Cart>? ShippedItems { get; set; }
        public List<Cart>? DeliveredItems { get; set; }
        public int CartCount { get; set; }
        public int OrdersPlaced {  get; set; }
        public int OrdersConfirmed { get; set; }
        public int OrdersShipped { get; set; }
        public int OrdersReceived { get; set; }
        public decimal CartTotal { get; set; }
        public decimal PlacedTotal { get; set; }
        public decimal ConfirmedTotal { get; set; }
        public decimal ShippedTotal { get; set; }
        public decimal DeliveredTotal { get; set; }
        public List<ListingDTO> Listing { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace FoodServiceApp.Models
{
    public class CheckoutValidationDTO
    {
        [DisplayName("Credit Card Number")]
        [Required(ErrorMessage = "Credit Card Number is required")]
        [CreditCard(ErrorMessage = "Invalid Credit Card number")]
        public string CCNumber { get; set; }
        [DisplayName("Expiry Month")]
        [Required(ErrorMessage = "Credit Card Expiry Month is required")]
        [Range(01, 12)]
        public int ExpMonth { get; set; }
        [DisplayName("Expiry Year")]
        [Required(ErrorMessage = "Credit Card Expiry Year is required")]
        [CreditCardExpirationYear(ErrorMessage = "Invalid Expiration Year")]
        public int ExpYear { get; set; }
        [Required(ErrorMessage = "Credit Card CVC is required")]
        [CreditCardCvc(ErrorMessage = "Invalid CVC")]
        public string CVC { get; set; }
    }
}

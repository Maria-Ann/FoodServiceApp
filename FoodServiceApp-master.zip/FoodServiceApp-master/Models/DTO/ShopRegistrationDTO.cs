﻿using System.ComponentModel.DataAnnotations;

namespace FoodServiceApp.Models
{
    public class ShopRegistrationDTO
    {
        [Required(ErrorMessage = "Please Enter your Shop's Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please Enter a Username")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Please Enter your Email")]
        [EmailAddress(ErrorMessage = "Invalid Email address. Please enter a Valid Email Address.")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please Enter a Password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please enter the Password once again to Verify")]
        [Compare("Password", ErrorMessage = "Passwords doesn't match. Please try again!")]
        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "Please enter your Phone number")]
        [Phone(ErrorMessage = "Invalid Phone number")]
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "Please enter your Address")]
        public Address ShopAddress { get; set; }
    }
}

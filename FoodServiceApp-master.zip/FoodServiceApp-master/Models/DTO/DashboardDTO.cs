﻿namespace FoodServiceApp.Models
{
    public class DashboardDTO
    {
        public int ShopId { get; set; }
        public Shop? Shop { get; set; }
        public ShopServices? ShopServices { get; set; }
        public List<FoodCategory>? FoodCategories { get; set; }
        public List<FoodItem>? FoodItems { get; set; }
    }
}

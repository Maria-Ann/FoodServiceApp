﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace FoodServiceApp.Models
{
    public class CheckoutDTO
    {
        public List<Cart> CartItems { get; set; }
        public UserData UserInformation { get; set; }
        public List<Address> UserAddresses { get; set; }
        [Required(ErrorMessage = "A Billing Address is Required")]
        public Address SelectedBillingAddress { get; set; }
        [Required(ErrorMessage = "A Delivery Address is Required")]
        public Address SelectedDeliveyAddress { get; set; }
        [DisplayName("Credit Card Number")]
        [Required(ErrorMessage = "Credit Card Number is required")]
        [CreditCard(ErrorMessage = "Invalid Credit Card number")]
        public string CCNumber { get; set; }
        [DisplayName("Expiry Month")]
        [Required(ErrorMessage = "Credit Card Expiry Month is required")]
        [Range(01,12)]
        public int ExpMonth { get; set; }
        [DisplayName("Expiry Year")]
        [Required(ErrorMessage = "Credit Card Expiry Year is required")]
        [CreditCardExpirationYear(ErrorMessage = "Invalid Expiration Year")]
        public int ExpYear { get; set; }
        [Required(ErrorMessage = "Credit Card CVC is required")]
        [CreditCardCvc(ErrorMessage = "Invalid CVC")]
        public string CVC { get; set; }
    }
    public class CreditCardCvcAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var cvc = (string)value;

            if (cvc == null || !(cvc.Length == 3 || cvc.Length == 4) || !int.TryParse(cvc, out _))
            {
                return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }
    }

    public class CreditCardExpirationYearAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var expirationYear = (int)value;

            if (expirationYear <= DateTime.Now.Year)
            {
                return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }
    }

}

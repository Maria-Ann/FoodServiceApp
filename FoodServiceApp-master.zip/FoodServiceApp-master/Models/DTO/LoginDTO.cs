﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace FoodServiceApp.Models
{
    public class LoginDTO
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter the Username")]
        [DisplayName("Username")]
        public string Username { get; set; }
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please enter the Password")]
        [PasswordPropertyText]
        [DisplayName("Password")]
        public string Password { get; set; }

        [DisplayName("Login as Service Provider")]
        public bool LoginAsAdmin { get; set; }
        public string? ErrorMessage { get; set; }
    }
}

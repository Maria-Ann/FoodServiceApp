﻿namespace FoodServiceApp.Models
{
    public class ListingDTO
    {
        public Shop shop { get; set; }
        public ShopServices shopServices { get; set; }
        public Address shopAddress { get; set; }
        public List<FoodCategory> foodCategories { get; set; }
        public List<FoodItem> foodItems { get; set; }
    }
}

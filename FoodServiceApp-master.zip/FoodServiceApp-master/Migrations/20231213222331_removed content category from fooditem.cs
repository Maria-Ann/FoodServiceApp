﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FoodServiceApp.Migrations
{
    public partial class removedcontentcategoryfromfooditem : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FoodItems_FoodContentCategories_ContentCategoryId",
                table: "FoodItems");

            migrationBuilder.DropTable(
                name: "FoodContentCategories");

            migrationBuilder.DropIndex(
                name: "IX_FoodItems_ContentCategoryId",
                table: "FoodItems");

            migrationBuilder.DropColumn(
                name: "ContentCategoryId",
                table: "FoodItems");

            migrationBuilder.AlterColumn<bool>(
                name: "IsOutOfStock",
                table: "FoodItems",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsAlcoholic",
                table: "FoodItems",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsVegan",
                table: "FoodItems",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsAlcoholic",
                table: "FoodItems");

            migrationBuilder.DropColumn(
                name: "IsVegan",
                table: "FoodItems");

            migrationBuilder.AlterColumn<bool>(
                name: "IsOutOfStock",
                table: "FoodItems",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AddColumn<int>(
                name: "ContentCategoryId",
                table: "FoodItems",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "FoodContentCategories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IsAlcoholic = table.Column<bool>(type: "bit", nullable: true),
                    IsNonVeg = table.Column<bool>(type: "bit", nullable: true),
                    IsVegan = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FoodContentCategories", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FoodItems_ContentCategoryId",
                table: "FoodItems",
                column: "ContentCategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_FoodItems_FoodContentCategories_ContentCategoryId",
                table: "FoodItems",
                column: "ContentCategoryId",
                principalTable: "FoodContentCategories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

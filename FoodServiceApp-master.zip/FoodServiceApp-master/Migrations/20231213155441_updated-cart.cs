﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FoodServiceApp.Migrations
{
    public partial class updatedcart : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "FoodItemId",
                table: "Carts",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Carts_FoodItemId",
                table: "Carts",
                column: "FoodItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_Carts_FoodItems_FoodItemId",
                table: "Carts",
                column: "FoodItemId",
                principalTable: "FoodItems",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Carts_FoodItems_FoodItemId",
                table: "Carts");

            migrationBuilder.DropIndex(
                name: "IX_Carts_FoodItemId",
                table: "Carts");

            migrationBuilder.DropColumn(
                name: "FoodItemId",
                table: "Carts");
        }
    }
}

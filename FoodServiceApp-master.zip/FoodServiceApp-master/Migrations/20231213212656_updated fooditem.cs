﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FoodServiceApp.Migrations
{
    public partial class updatedfooditem : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ContentCategory",
                table: "FoodItems",
                newName: "ContentCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_FoodItems_CategoryId",
                table: "FoodItems",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_FoodItems_ContentCategoryId",
                table: "FoodItems",
                column: "ContentCategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_FoodItems_FoodCategories_CategoryId",
                table: "FoodItems",
                column: "CategoryId",
                principalTable: "FoodCategories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_FoodItems_FoodContentCategories_ContentCategoryId",
                table: "FoodItems",
                column: "ContentCategoryId",
                principalTable: "FoodContentCategories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FoodItems_FoodCategories_CategoryId",
                table: "FoodItems");

            migrationBuilder.DropForeignKey(
                name: "FK_FoodItems_FoodContentCategories_ContentCategoryId",
                table: "FoodItems");

            migrationBuilder.DropIndex(
                name: "IX_FoodItems_CategoryId",
                table: "FoodItems");

            migrationBuilder.DropIndex(
                name: "IX_FoodItems_ContentCategoryId",
                table: "FoodItems");

            migrationBuilder.RenameColumn(
                name: "ContentCategoryId",
                table: "FoodItems",
                newName: "ContentCategory");
        }
    }
}
